from parallel_wavegan.losses.stft_loss import *  # NOQA

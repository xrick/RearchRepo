from parallel_wavegan.models.parallel_wavegan import *  # NOQA

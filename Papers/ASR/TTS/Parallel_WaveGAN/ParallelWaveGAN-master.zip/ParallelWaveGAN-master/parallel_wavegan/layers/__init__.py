from parallel_wavegan.layers.residual_block import *  # NOQA
from parallel_wavegan.layers.upsample import *  # NOQA

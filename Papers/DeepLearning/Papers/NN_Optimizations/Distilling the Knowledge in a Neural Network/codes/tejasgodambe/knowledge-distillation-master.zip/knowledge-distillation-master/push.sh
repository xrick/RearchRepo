#!/bin/bash 

git add -A :/ 
git commit -m "test"
git push

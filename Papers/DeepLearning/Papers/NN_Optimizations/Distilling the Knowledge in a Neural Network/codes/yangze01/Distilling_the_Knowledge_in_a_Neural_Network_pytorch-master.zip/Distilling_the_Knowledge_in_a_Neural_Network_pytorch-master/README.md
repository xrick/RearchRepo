# Reproduce Distilling_the_Knowledge_in_a_Neural_Network using pytorch
paper address: https://arxiv.org/pdf/1503.02531.pdf

reproduce the paper on text classification using pytorch.

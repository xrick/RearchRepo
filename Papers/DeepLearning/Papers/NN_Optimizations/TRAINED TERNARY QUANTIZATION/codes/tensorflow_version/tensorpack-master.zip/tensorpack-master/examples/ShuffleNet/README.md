
Moved to [../ImageNetModels](../ImageNetModels/).

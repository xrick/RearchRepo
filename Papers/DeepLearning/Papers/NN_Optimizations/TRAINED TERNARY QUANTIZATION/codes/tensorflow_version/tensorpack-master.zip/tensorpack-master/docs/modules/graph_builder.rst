tensorpack.graph_builder package
================================

These are some useful functions if you need to write your own trainers.
Otherwise you probably don't need to use them.

.. automodule:: tensorpack.graph_builder
    :members:
    :undoc-members:
    :show-inheritance:

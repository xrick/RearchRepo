Moved to [../CaffeModels](../CaffeModels).

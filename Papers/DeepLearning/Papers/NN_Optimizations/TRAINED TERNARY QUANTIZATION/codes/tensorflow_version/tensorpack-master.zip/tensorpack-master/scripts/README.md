
These scripts are some helpful utilities about the library.

They are meant to be __examples__ on how to do some basic model manipulation
with tensorpack. The scripts themselves are not part of the library and
therefore are not subject to any compatibility guarantee.

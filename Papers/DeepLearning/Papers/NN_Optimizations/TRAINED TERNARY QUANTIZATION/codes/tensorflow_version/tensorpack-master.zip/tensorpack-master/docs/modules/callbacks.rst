tensorpack.callbacks package
============================

**Everything** other than the training iterations happen in the callbacks.
Most of the fancy things you want to do will probably end up here.
See relevant tutorials: :doc:`../tutorial/callback`.

.. container:: custom-index

    .. raw:: html

        <script type="text/javascript" src='../_static/build_toc_group.js'></script>


.. automodule:: tensorpack.callbacks
    :members:
    :no-undoc-members:
    :show-inheritance:

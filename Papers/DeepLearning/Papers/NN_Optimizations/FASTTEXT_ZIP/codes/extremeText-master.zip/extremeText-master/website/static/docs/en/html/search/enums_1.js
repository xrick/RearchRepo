var searchData=
[
  ['loss_5fname',['loss_name',['../namespacefasttext.html#a1ba04862fd670674501ccacc936e1952',1,'fasttext']]]
];

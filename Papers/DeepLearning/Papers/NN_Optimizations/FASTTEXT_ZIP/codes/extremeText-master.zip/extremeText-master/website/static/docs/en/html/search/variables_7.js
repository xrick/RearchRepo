var searchData=
[
  ['input',['input',['../classfasttext_1_1Args.html#a6377f6e903dd4f991ffd477a7a4392dd',1,'fasttext::Args']]],
  ['input_5f',['input_',['../classfasttext_1_1FastText.html#aa25683f12eed057c159fd11fd3a55efb',1,'fasttext::FastText']]]
];

var searchData=
[
  ['l2normrow',['l2NormRow',['../classfasttext_1_1Matrix.html#aa61bc6b1a1b2467d7fb41a9e99d96922',1,'fasttext::Matrix::l2NormRow(int64_t i) const'],['../classfasttext_1_1Matrix.html#afb690a9d64bc7e941cbd48f20cab872e',1,'fasttext::Matrix::l2NormRow(Vector &amp;norms) const']]],
  ['label',['label',['../classfasttext_1_1Args.html#a1c072949833ab403ef53184dcb77b642',1,'fasttext::Args::label()'],['../namespacefasttext.html#a532eedeee97e8d66a96b519d165f4eb7ad304ba20e96d87411588eeabac850e34',1,'fasttext::label()']]],
  ['lastdsub_5f',['lastdsub_',['../classfasttext_1_1ProductQuantizer.html#ae79be52ccbb6230ce129234e150bc826',1,'fasttext::ProductQuantizer']]],
  ['left',['left',['../structfasttext_1_1Node.html#a44f47a277a7fc982be30569befc7d8c1',1,'fasttext::Node']]],
  ['load',['load',['../classfasttext_1_1Args.html#a7f7c0f446795a8ffa23db55583ae29c4',1,'fasttext::Args::load()'],['../classfasttext_1_1Dictionary.html#a3bb32f8fb16493e1e0acb5444d266ca3',1,'fasttext::Dictionary::load()'],['../classfasttext_1_1Matrix.html#a8a04afebc25fcf38376f272371e0b60d',1,'fasttext::Matrix::load()'],['../classfasttext_1_1ProductQuantizer.html#a4060617809c0099a9e5ca73ec0497056',1,'fasttext::ProductQuantizer::load()'],['../classfasttext_1_1QMatrix.html#a03c039b81b5aaed30d95149de9379998',1,'fasttext::QMatrix::load()']]],
  ['loadmodel',['loadModel',['../classfasttext_1_1FastText.html#ae0e6922404294aabbb9d6322e6f464cd',1,'fasttext::FastText::loadModel(std::istream &amp;)'],['../classfasttext_1_1FastText.html#ac844ddc1573e80a8b5a255668fc97247',1,'fasttext::FastText::loadModel(const std::string &amp;)']]],
  ['loadvectors',['loadVectors',['../classfasttext_1_1FastText.html#a9e503be304e98ead00a2eaed3127f64a',1,'fasttext::FastText']]],
  ['log',['log',['../classfasttext_1_1Model.html#af797332e236982f2570a3b94b686e816',1,'fasttext::Model']]],
  ['log_5ftable_5fsize',['LOG_TABLE_SIZE',['../model_8h.html#a39f445c336c3e871eccbaa0423b6daef',1,'model.h']]],
  ['loss',['loss',['../classfasttext_1_1Args.html#a02be205f9a7c002aad68924f426b7290',1,'fasttext::Args']]],
  ['loss_5f',['loss_',['../classfasttext_1_1Model.html#a3cc48ada470c99ef69840cf79967616e',1,'fasttext::Model']]],
  ['loss_5fname',['loss_name',['../namespacefasttext.html#a1ba04862fd670674501ccacc936e1952',1,'fasttext']]],
  ['lr',['lr',['../classfasttext_1_1Args.html#ad6f86c95de9402344106570e6a917445',1,'fasttext::Args']]],
  ['lrupdaterate',['lrUpdateRate',['../classfasttext_1_1Args.html#a66876acfb52e46dc166b77d7db15889d',1,'fasttext::Args']]]
];

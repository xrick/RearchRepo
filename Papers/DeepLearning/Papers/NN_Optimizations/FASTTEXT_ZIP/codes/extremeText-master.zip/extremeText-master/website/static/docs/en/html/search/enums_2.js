var searchData=
[
  ['model_5fname',['model_name',['../namespacefasttext.html#a349df214746a2ea0e5d7c26326b03d6f',1,'fasttext']]]
];
